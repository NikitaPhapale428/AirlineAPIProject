package com.example.demo.airlineproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
